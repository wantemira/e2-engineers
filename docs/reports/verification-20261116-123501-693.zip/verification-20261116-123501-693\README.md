﻿# AI-Buddy verification reports

Revision: 12b8e1b61614c3b3bc0b9cc42930152325216c9f
UTC: 2026-11-16T07:37:03.8188175Z
Backend lines: 2571 / 3052 (84.23%)
Frontend lines: 398 / 453 (87.85%)
Combined application lines: 84.7%
Tracked working tree changes: 2

Open backend/coverage.html and frontend/coverage/index.html in a browser.
Open frontend/playwright-report/index.html for the browser test report.
Machine-readable evidence: backend/coverage.xml, backend/coverage.out,
frontend/coverage/coverage-summary.json, frontend/coverage/lcov.info, summary.json.

Coverage includes all backend cmd/internal packages and frontend application src,
including files without tests; dependencies, generated files and tests are excluded.
Go source lines use gocover-cobertura v1.5.0; TypeScript lines use Istanbul.
training/orders is a separate teaching exercise: its solution tests are checked,
and its deliberately broken initial version is outside the AI-Buddy application metric.

The automated suite uses synthetic services and a test LLM API. It does not call
the configured Live provider or verify Docker startup. The functional scenario
and expected results are documented in docs/demo.md.

Only generated reports and this summary are packaged. The script does not read .env
or copy project configuration, model keys, application state, or the source repository.
